int main()
{
	int a=5;
	b=3;
	float c=4.5;
	c=6.5;
	double d=5.44;
	double e=d+9.0-4.0/2.0;
}
